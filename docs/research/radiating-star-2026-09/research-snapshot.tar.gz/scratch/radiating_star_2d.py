"""Experimental steady meridional M1 continuation; dimensionless 4piG=Rgas=Tc=rhoc=1."""
import argparse
import json
import numpy as np
from scipy.integrate import solve_ivp, cumulative_trapezoid
from scipy.interpolate import PchipInterpolator
from scipy.optimize import least_squares
from scipy.sparse import lil_matrix
from scipy.special import eval_legendre
from m1_star_beta8 import run, eos

def spherical(kappa=100., cut=.015):
    core,_,rhs=run(kappa,cut,rtol=1e-10)
    rc=core.t[-1]; rhoc,mc,fc=core.y[:,-1]
    tc,ec,_,pc,pcr=eos(rhoc)
    gam=pcr*rhoc/pc; kg=pc/rhoc**gam
    hc=gam/(gam-1)*tc; lum=rc*rc*fc*ec
    def outer(r,y):
        h,m,f=y
        rho=(max(h,0)*(gam-1)/(gam*kg))**(1/(gam-1))
        root=np.sqrt(max(1e-14,4-3*f*f)); d=1/3+2*f*f/(2+root); dp=2*f/root
        return [-m/r**2,r*r*rho,f/r*(d-1)/(d-f*dp)]
    def surface(r,y):return y[0]
    surface.terminal=True;surface.direction=-1
    envelope=solve_ivp(outer,[rc,100],[hc,mc,fc],events=surface,rtol=1e-11,atol=1e-12,dense_output=True,max_step=.04)
    rs=envelope.t[-1]; ms=envelope.y[1,-1]
    vacuum=solve_ivp(outer,[rs,4*rs],envelope.y[:,-1],rtol=1e-11,atol=1e-12,dense_output=True,max_step=.1)
    rg=np.linspace(0,4*rs,12001)
    inner=rg<rc; env=(rg>=rc)&(rg<rs); vac=rg>=rs
    rho=np.zeros_like(rg); temp=rho.copy(); e=rho.copy(); f=rho.copy(); m=rho.copy()
    rhoi,mi,fi=core.sol(np.maximum(rg[inner],core.t[0])); rhoi[0]=1;mi[0]=0;fi[0]=0
    rho[inner]=rhoi;m[inner]=mi;f[inner]=fi
    vals=np.array([eos(r) for r in rhoi]);temp[inner]=vals[:,0];e[inner]=vals[:,1]
    he,me,fe=envelope.sol(rg[env]);rho[env]=(he*(gam-1)/(gam*kg))**(1/(gam-1));temp[env]=kg*rho[env]**(gam-1);m[env]=me;f[env]=fe
    _,mv,fv=vacuum.sol(rg[vac]);m[vac]=ms;f[vac]=fv
    e[~inner]=lum/(rg[~inner]**2*f[~inner])
    force=np.divide(m,rg*rg,out=np.zeros_like(m),where=rg>0)
    integ=cumulative_trapezoid(force,rg,initial=0)
    phi=-ms/rg[-1]-(integ[-1]-integ)
    # Barotropic gas enthalpy, continuously joined to the transparent envelope.
    densities=np.geomspace(cut,2,6000); es=np.array([eos(x) for x in densities])
    integrals=hc+cumulative_trapezoid(es[:,4]/densities,densities,initial=0)
    h_of_rho=PchipInterpolator(densities,integrals)
    h=np.zeros_like(rg);h[inner]=h_of_rho(rho[inner]);h[env]=he;h[vac]=-ms/rs+ms/rg[vac]
    # EOS on the whole h interval, including vacuum.
    denlow=np.geomspace(1e-18,cut,2500)[:-1]
    den=np.r_[0,denlow,densities]
    htab=np.r_[0,gam/(gam-1)*kg*denlow**(gam-1),integrals]
    ttab=np.r_[0,kg*denlow**(gam-1),es[:,0]]
    info=dict(R=rs,M=ms,rc=rc,cut=cut,kappa=kappa,gammaEnvelope=gam,lum=lum,hc=h[0])
    interp={key:PchipInterpolator(rg,value) for key,value in dict(rho=rho,h=h,E=e,f=f,phi=phi).items()}
    interp['density']=PchipInterpolator(htab,den,extrapolate=True)
    interp['temperature']=PchipInterpolator(htab,ttab,extrapolate=True)
    return info,interp

class Model:
    def __init__(self,n=25,spin=.1):
        self.info,self.ref=spherical();self.n=n
        self.x=np.linspace(0,1.7*self.info['R'],n);self.dx=self.x[1]
        self.R,self.Z=np.meshgrid(self.x,self.x,indexing='ij');self.r=np.hypot(self.R,self.Z)
        self.omega2=spin**2*self.info['M']/self.info['R']**3
        ref=self.ref;r=self.r;E=ref['E'](r);f=ref['f'](r)
        w=f/np.sqrt(1-f*f)
        self.Eref=E
        self.hscale=self.info['hc'];self.forceScale=np.maximum(.02,self.info['M']/(1+r*r))
        self.radScale=np.maximum(1e-7,E/np.maximum(r,1))
        wR=np.divide(w*self.R,r,out=np.zeros_like(r),where=r>0)
        wZ=np.divide(w*self.Z,r,out=np.zeros_like(r),where=r>0)
        self.initial=np.array([ref['h'](r)/self.hscale,np.zeros_like(r),wR,wZ,ref['phi'](r)/self.hscale])
        self.phib=ref['phi'](r)
        self.mask=ref['rho'](r)>self.info['cut']
        # Prescribed spatial opacity, held fixed just like the eventual source.
        self.kappa=self.info['kappa']*np.maximum(0,1-self.info['cut']/np.maximum(ref['rho'](r),1e-30))**2
        self.calls=0

    def grad(self,a,oddR=False,oddZ=False):
        ar=np.gradient(a,self.dx,axis=0,edge_order=2);az=np.gradient(a,self.dx,axis=1,edge_order=2)
        ar[0]=a[1]/self.dx if oddR else 0
        az[:,0]=a[:,1]/self.dx if oddZ else 0
        return ar,az
    def decode(self,y):
        h,logE,wR,wZ,phi=y.reshape(5,self.n,self.n)
        h=h*self.hscale;phi=phi*self.hscale
        rho=np.maximum(self.ref['density'](np.maximum(0,h)),0)
        T=np.maximum(self.ref['temperature'](np.maximum(0,h)),0)
        E=self.Eref*np.exp(np.clip(logE,-30,30));d=np.sqrt(1+wR*wR+wZ*wZ)
        FR=E*wR/d;FZ=E*wZ/d
        kap=self.kappa
        return h,phi,rho,T,E,FR,FZ,kap

    def residual(self,y):
        self.calls+=1
        n=self.n;dx=self.dx;R=self.R;Z=self.Z
        h,phi,rho,T,E,FR,FZ,kap=self.decode(y)
        hR,hZ=self.grad(h);pR,pZ=self.grad(phi)
        f2=(FR*FR+FZ*FZ)/(E*E);D=1/3+2*f2/(2+np.sqrt(np.maximum(1e-15,4-3*f2)))
        A=.5*(1-D)*E;B=3/(E*(2+np.sqrt(np.maximum(1e-15,4-3*f2))))
        PRR=A+B*FR*FR;PZZ=A+B*FZ*FZ;PRZ=B*FR*FZ
        rr,_=self.grad(PRR);rz,zrz=self.grad(PRZ,oddR=True,oddZ=True);_,zz=self.grad(PZZ)
        divPR=rr+zrz+np.divide(PRR-A,R,out=np.zeros_like(R),where=R>0)
        divPZ=rz+zz+np.divide(PRZ,R,out=np.zeros_like(R),where=R>0);divPZ[0]=2*rz[0]+zz[0]
        fr,_=self.grad(FR,oddR=True);_,fz=self.grad(FZ,oddZ=True)
        divF=fr+fz+np.divide(FR,R,out=np.zeros_like(R),where=R>0);divF[0]=2*fr[0]+fz[0]
        gas=(hZ+pZ-kap*FZ)/self.forceScale
        gas[:,0]=(hR[:,0]+pR[:,0]-kap[:,0]*FR[:,0]-self.omega2*self.x)/self.forceScale[:,0]
        gas[0,0]=(h[0,0]-self.hscale)/self.hscale
        radR=(divPR+kap*rho*FR)/self.radScale
        radZ=(divPZ+kap*rho*FZ)/self.radScale
        radR[0]=FR[0]/E[0];radZ[:,0]=FZ[:,0]/E[:,0]
        thermal=np.where(self.mask,(E-.75*T**4)/np.maximum(E,1e-8),divF/self.radScale)
        lap=np.zeros_like(phi)
        lap[1:-1,1:-1]=(phi[2:,1:-1]+phi[:-2,1:-1]+phi[1:-1,2:]+phi[1:-1,:-2]-4*phi[1:-1,1:-1])/dx**2+(phi[2:,1:-1]-phi[:-2,1:-1])/(2*dx*R[1:-1,1:-1])
        lap[0,1:-1]=4*(phi[1,1:-1]-phi[0,1:-1])/dx**2+(phi[0,2:]+phi[0,:-2]-2*phi[0,1:-1])/dx**2
        lap[1:-1,0]=(phi[2:,0]+phi[:-2,0]-2*phi[1:-1,0])/dx**2+(phi[2:,0]-phi[:-2,0])/(2*dx*R[1:-1,0])+2*(phi[1:-1,1]-phi[1:-1,0])/dx**2
        lap[0,0]=(4*(phi[1,0]-phi[0,0])+2*(phi[0,1]-phi[0,0]))/dx**2
        grav=lap-rho
        grav[-1]=(phi[-1]-self.phib[-1])/self.hscale
        grav[:,-1]=(phi[:,-1]-self.phib[:,-1])/self.hscale
        return np.array([gas,thermal,radR,radZ,grav]).ravel()

    def sparsity(self):
        n=self.n;N=n*n;j=lil_matrix((5*N,5*N),dtype=np.int8)
        for a in range(n):
          for b in range(n):
            sites={(a,b),(max(0,a-1),b),(min(n-1,a+1),b),(a,max(0,b-1)),(a,min(n-1,b+1))}
            if a in (0,n-1):sites.add((2 if a==0 else n-3,b))
            if b in (0,n-1):sites.add((a,2 if b==0 else n-3))
            for row in range(5):
              for col in range(5):
                for x,z in sites:j[row*N+a*n+b,col*N+x*n+z]=1
        return j.tocsr()

    def update_boundary(self,y):
        _,phi,rho,*_=self.decode(y);r=self.r;mu=np.divide(self.Z,r,out=np.zeros_like(r),where=r>0)
        boundary=np.zeros_like(r)
        for ell in range(0,9,2):
            pl=eval_legendre(ell,mu); integrand=rho*self.R*r**ell*pl
            moment=np.trapz(np.trapz(integrand,self.x,axis=1),self.x)
            boundary-=np.divide(moment*pl,r**(ell+1),out=np.zeros_like(r),where=r>0)
        self.phib=boundary

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--n',type=int,default=17);p.add_argument('--spin',type=float,default=0.);p.add_argument('--iterations',type=int,default=100);a=p.parse_args()
    model=Model(a.n,a.spin);y=model.initial.ravel()
    print('INFO',model.info,'initial',np.linalg.norm(model.residual(y)),flush=True)
    sparsity=model.sparsity()
    for outer in range(4):
        model.update_boundary(y)
        sol=least_squares(model.residual,y,jac_sparsity=sparsity,verbose=1,max_nfev=a.iterations,ftol=1e-11,xtol=1e-11,gtol=1e-9,x_scale='jac',tr_options={'atol':1e-10,'btol':1e-10,'maxiter':300})
        y=sol.x;r=model.residual(y).reshape(5,a.n,a.n)
        print('ITER',outer,'norm',np.linalg.norm(r),'blocks',[np.max(np.abs(q)) for q in r],'calls',model.calls,flush=True)
        np.savez(f'/tmp/radiating_star_2d_{a.n}_{a.spin}.npz',solution=y.reshape(5,a.n,a.n),x=model.x,info=json.dumps(model.info),residual=r)
