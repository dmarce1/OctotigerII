"""Read-only independent continuum audit of stored meridional references."""
import sys, os
import numpy as np
from scipy.interpolate import RectBivariateSpline
from radiating_star_spherical_piecewise_grid import SphericalModel

def audit(path):
 data=np.load(path);y=data['solution'];nr,nm=y.shape[1:];m=SphericalModel(nr,nm,0)
 if abs(data['x'][-1]-m.x[-1])>1e-10:
  m=SphericalModel(nr,nm,0,2*float(data['x'][-1])/m.x[-1])
 m.omega2=float(data['spin'])*float(data['spin'])*m.info['M']/m.info['R']**3
 # Differentiate smooth corrections independently of the solver's centered/backward stencil.
 delta=y-m.initial;ic=(nr-1)//2;splines=[[RectBivariateSpline(m.x[:ic+1],m.mu,z[:ic+1],kx=3,ky=3,s=0),RectBivariateSpline(m.x[ic:],m.mu,z[ic:],kx=3,ky=3,s=0)] for z in delta]
 x=(m.x[:-1]+m.x[1:])/2;mu=(m.mu[:-1]+m.mu[1:])/2
 if os.environ.get('STAR_AUDIT_COMMON'):
  x=np.unique(np.r_[np.linspace(.12,.85*m.info['rc'],161),np.linspace(.85*m.info['rc'],m.info['rc']-1e-6,257),np.linspace(m.info['rc']+1e-6,1.05*m.info['rc'],129),np.linspace(1.05*m.info['rc'],1.1*m.info['R'],129)]);mu=np.linspace(.025,.975,65)
 r,u=np.meshgrid(x,mu,indexing='ij');S=1-u*u
 def corr(i,dx=0,dy=0):
  inside=x<=m.info['rc'];out=np.empty((len(x),len(mu)))
  out[inside]=splines[i][0](x[inside],mu,dx=dx,dy=dy);out[~inside]=splines[i][1](x[~inside],mu,dx=dx,dy=dy)
  return out
 href=m.ref['h'](r);pref=m.ref['phi'](r);er=m.ref['E'](r);fr=m.ref['f'](r)
 h=href+m.hscale*corr(0);p=pref+m.hscale*corr(4);E=er*np.exp(corr(1));f=fr+corr(2);q=corr(3);F=E*f;Q=E*q
 rho=np.maximum(m.ref['density'](np.maximum(h,0)),0);T=np.maximum(m.ref['temperature'](np.maximum(h,0)),0)
 E=np.where(r<=m.info['rc'],.75*T**4,E);F=E*f;Q=E*q
 # Reference h+Phi radial derivative is reference radiation acceleration analytically.
 kref=100*np.maximum(0,1-.015/np.maximum(m.ref['rho'](r),1e-30))**2
 kref[r>=m.info['rc']]=0
 baseForce=kref*er*fr
 Sr=baseForce+m.hscale*(corr(0,1)+corr(4,1));Sm=m.hscale*(corr(0,0,1)+corr(4,0,1))
 omega2=(Sr-u*Sm/r-kref*(F-u*Q))/r
 Er=E*(m.ref['E'].derivative()(r)/er+corr(1,1));Em=E*corr(1,0,1)
 Th=m.ref['temperature'].derivative()(np.maximum(h,0));Er=np.where(r<=m.info['rc'],3*T**3*Th*(m.ref['h'].derivative()(r)+m.hscale*corr(0,1)),Er);Em=np.where(r<=m.info['rc'],3*T**3*Th*m.hscale*corr(0,0,1),Em)
 Fr=Er*f+E*(m.ref['f'].derivative()(r)+corr(2,1));Qm=Em*q+E*corr(3,0,1)
 j=Fr+(2*F+S*Qm-2*u*Q)/r
 # Full M1 continuum derivative by the chain rule.
 f2=f*f+S*q*q;root=np.sqrt(4-3*f2);d=3/(2+root)
 def pressure(df,dq,dE,dS):
  df2=2*f*df+2*S*q*dq+dS*q*q;ds=-1.5*df2/root;dd=-d*ds/(2+root)
  A=E*(root-1)/3;A1=(dE*(root-1)+E*ds)/3
  P=A+E*d*f*f;P1=A1+(dE*d+E*dd)*f*f+2*E*d*f*df
  C=E*d*f*q;C1=(dE*d+E*dd)*f*q+E*d*(df*q+f*dq)
  D=E*d*q*q;D1=(dE*d+E*dd)*q*q+2*E*d*q*dq
  return A,P,C,D,A1,P1,C1,D1
 A,P,C,D,Ar,Pr,Cr,Dr=pressure(m.ref['f'].derivative()(r)+corr(2,1),corr(3,1),Er,0)
 _,_,_,_,Am,Pm,Cm,Dm=pressure(corr(2,0,1),corr(3,0,1),Em,-2*u)
 rr=Pr+(2*P-2*A-S*D+S*Cm-2*u*C)/r+kref*rho*F
 rz=Cr+(3*C+Am+S*Dm-3*u*D)/r+kref*rho*Q
 gas=u*Sr+S*Sm/r-kref*(u*F+S*Q)
 # Poisson defect relative the radial exact background; reference density uses the ODE.
 phir=m.hscale*corr(4,1);phirr=m.hscale*corr(4,2);phim=m.hscale*corr(4,0,1);phimm=m.hscale*corr(4,0,2)
 grav=phirr+2*phir/r+(S*phimm-2*u*phim)/r**2-(rho-m.ref['rho'](r))
 scale=np.maximum(E/np.maximum(r,1),1e-7);fs=np.maximum(.02,m.info['M']/(1+r*r))
 thermal=(E-.75*T**4)/np.maximum(E,1e-8)
 active=(r<m.info['rc'])&(kref>0)
 # Adiabatic stability diagnostics from independent derivatives.
 hr=m.ref['h'].derivative()(r)+m.hscale*corr(0,1);hm=m.hscale*corr(0,0,1)
 rootS=np.sqrt(S);R=r*rootS
 hR=rootS*(hr-u*hm/r);hz=u*hr+S*hm/r
 rhoh=m.ref['density'].derivative()(np.maximum(h,0))
 Th=m.ref['temperature'].derivative()(np.maximum(h,0))
 refRho=m.ref['rho'](r);refRhoR=m.ref['rho'].derivative()(r)
 kr=np.where(r<m.info['rc'],200*np.maximum(0,1-.015/np.maximum(refRho,1e-30))*.015/np.maximum(refRho,1e-30)**2*refRhoR,0)
 delta=(F-er*fr-u*Q)
 Qr=Er*q+E*corr(3,1);Fm=Em*f+E*corr(2,0,1)
 refFr=m.ref['E'].derivative()(r)*fr+er*m.ref['f'].derivative()(r)
 numerator=m.hscale*(corr(0,1)+corr(4,1))-u*m.hscale*(corr(0,0,1)+corr(4,0,1))/r-kref*delta
 nr=m.hscale*(corr(0,2)+corr(4,2))-u*m.hscale*(corr(0,1,1)+corr(4,1,1))/r+u*m.hscale*(corr(0,0,1)+corr(4,0,1))/r**2-kr*delta-kref*(Fr-refFr-u*Qr)
 nm=m.hscale*(corr(0,1,1)+corr(4,1,1))-m.hscale*(corr(0,0,1)+corr(4,0,1))/r-u*m.hscale*(corr(0,0,2)+corr(4,0,2))/r-kref*(Fm-Q-u*Qm)
 omr=nr/r-numerator/r**2;omm=nm/r
 omR=rootS*(omr-u*omm/r);omz=u*omr+S*omm/r
 rayleigh=4*omega2+R*omR
 jr=R**3*rayleigh;jz=R**4*omz
 for region,domain,mixture in [('LTE_diffusion',(f2<.01)&(r<.85*m.info['rc'])&(rho>.02),True),('LTE_all',(r<m.info['rc']-1e-6)&(rho>.02),True),('transparent_gas',(r>m.info['rc']+.1)&(rho>1e-5),False)]:
  safeRho=np.maximum(rho,1e-30);safeT=np.maximum(T,1e-30)
  sh=1.5*Th/safeT-rhoh/safeRho
  ph=rhoh*T+rho*Th
  sensitivity=np.full_like(r,.4)
  if mixture:
   sh+=3*T*T*Th/safeRho-T**3*rhoh/safeRho**2
   ph+=T**3*Th
   ratio=T**3/safeRho;sensitivity=(1+ratio)/(2.5+5*ratio+ratio*ratio)
  n2=-sensitivity/safeRho*ph*sh*(hR*hR+hz*hz)
  sh1=rayleigh+n2
  sh2=-sensitivity/(safeRho*R**3)*(ph*hz)*(jr*sh*hz-jz*sh*hR)
  shear=R*omz/(2*np.maximum(omega2,1e-30))
  def ss(a):return [float(np.min(a[domain])),float(np.max(a[domain])),int(np.count_nonzero(a[domain]<0))]
  print('STABILITY',region,'Rayleigh',ss(rayleigh),'N2',ss(n2),'SH1',ss(sh1),'SH2',ss(sh2),'R_dlnOmega_dz',ss(shear),'points',int(np.count_nonzero(domain)))
 print('SOURCE_AUDIT','opaque_min_j',float(j[active].min()),'opaque_negative_count',int(np.count_nonzero(j[active]<0)),'thermal_over_positive_j',float(np.max(np.abs((kref*rho*(E-.75*T**4)/np.maximum(j,1e-20))[active]))))
 print('\nMODEL',path,'spin',float(data['spin']),'omega2_equator',m.omega2,'maxf',np.sqrt(f2).max())
 for name,mask in [('bulk',r<.85*m.info['rc']),('opaque',r<m.info['rc']-1e-10),('layer',(r>m.info['rc']-.2)&(r<m.info['rc'])),('transition',(r>=.85*m.info['rc'])&(r<=1.05*m.info['rc'])),('material',rho>1e-5),('transparent',r>1.05*m.info['rc'])]:
  if not np.any(mask):continue
  def stat(z):return [float(np.min(z[mask])),float(np.max(z[mask])),float(np.sqrt(np.mean(z[mask]**2)))]
  
  if name=='opaque':
   for label,val in [('radR',rr/scale),('radMu',rz*np.sqrt(S)/scale),('thermal',thermal),('gas',gas/fs)]:
    flat=np.where(mask.ravel())[0][np.argmax(abs(val[mask]))];i,jj=np.unravel_index(flat,r.shape);print('PEAK',label,'r',r[i,jj],'mu',u[i,jj],'rho',rho[i,jj],'value',val[i,jj])
  print(name,'omega2',stat(omega2),'j',stat(j),'gas',stat(gas/fs),'radR',stat(rr/scale),'radMu',stat(rz/scale),'grav',stat(grav),'thermal',stat(thermal))
 return m,y,omega2
if __name__=='__main__':
 for path in sys.argv[1:]:audit(path)
