"""Independent first-order azimuthal solve on saved r-mu meridional fields."""
import sys
import numpy as np
from scipy.interpolate import RectBivariateSpline
from scipy.sparse import lil_matrix,diags,kron,eye
from scipy.sparse.linalg import spsolve
from radiating_star_spherical_grid import SphericalModel
for path in sys.argv[1:]:
 data=np.load(path);y=data['solution'];nr,nm=y.shape[1:];m=SphericalModel(nr,nm,0);m.omega2=float(data['spin'])**2*m.info['M']/m.info['R']**3
 h,p,rho,T,E,F,Q=m.decode(y);r=m.r;u=m.MU;S=m.S;k=m.kappa;ch=k*rho;B=.75*T**4
 # independent smooth derivative of gas/gravity corrections determines the inertial speed.
 ds=y[0]+y[4]-m.initial[0]-m.initial[4];sp=RectBivariateSpline(m.x,m.mu,ds,kx=3,ky=3)
 dr=sp(m.x,m.mu,dx=1)*m.hscale;dm=sp(m.x,m.mu,dy=1)*m.hscale
 ir=np.divide(1,r,out=np.zeros_like(r),where=r>0)
 O2=(dr-u*ir*dm-k*(F-u*Q-m.Eref*m.ref['f'](r)))*ir;O2[0]=m.omega2
 if np.min(O2)<0:raise ValueError(('negative omega2',O2.min()))
 omega=np.sqrt(O2);b=omega*m.R/520.3913333975482
 f=F/E;q=Q/E;s=np.sqrt(4-3*(f*f+S*q*q));d=3/(s+2);ar=d*f;am=d*q;P0=E*(s-1)/3
 back=lil_matrix((nr,nr))
 back[1,0]=-1/m.dr;back[1,1]=1/m.dr
 for i in range(2,nr):back[i,i]=1.5/m.dr;back[i,i-1]=-2/m.dr;back[i,i-2]=.5/m.dr
 der=kron(back.tocsr(),eye(nm),format='csr');diag=lambda z:diags(z.ravel())
 mat=der@diag(ar)+diag(S*ir)@m.me@diag(am)+diag(4*ir*(ar-u*am)+ch)
 rhs=ch*(P0+B)*omega/520.3913333975482
 mat=mat.tolil();a1=ar[1]/m.dr
 for j in range(nm):mat[j]=0;mat[j,j]=1;rhs[0,j]=(ch[0,j]*(P0[0,j]+B[0,j])*omega[0,j]/520.3913333975482)/(ch[0,j]+5*a1[j])
 w=spsolve(mat.tocsc(),rhs.ravel()).reshape(nr,nm);qphi=m.R*w;t=qphi/E
 sf=np.sqrt(4-3*(f*f+S*q*q+t*t));df=3/(sf+2);Pphi=E*(sf-1)/3+df*qphi*qphi/E
 # Separate actual node interpolation residual from the velocity-specific defect.
 moving=-2*b*qphi+b*b*(Pphi+B)
 exactB=(E-2*b*qphi+b*b*Pphi)/(1-b*b)
 gphi=ch*(qphi-(Pphi+exactB)*b)
 Fr=(m.ro@F.ravel()).reshape(nr,nm);Qm=(m.mo@Q.ravel()).reshape(nr,nm)
 j0=Fr+ir*(2*F+S*Qm-2*u*Q)
 mask=m.mask&(r>0)
 print('TORUS',path,'omega2Min',O2[rho>1e-5].min(),'max_v_c',b[rho>1e-5].max(),'maxq_E',abs(t).max(),'cone',np.sqrt(f*f+S*q*q+t*t).max())
 print('moving_thermal_E',abs(moving[mask]/E[mask]).max(),'moving_thermal_j',abs(ch[mask]*moving[mask]/j0[mask]).max(),'node_static_thermal_E',abs((E[mask]-B[mask])/E[mask]).max(),'meridional_force_frac',abs(b[mask]*df[mask]*t[mask]).max(),'rotation_work_j',abs(b[mask]*gphi[mask]/j0[mask]).max())
