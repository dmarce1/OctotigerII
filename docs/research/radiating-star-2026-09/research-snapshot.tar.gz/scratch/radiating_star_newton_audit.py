"""Independent sparse direct Newton audit of the root's stationary prototype."""
import argparse,time,warnings
import numpy as np
from scipy.optimize._numdiff import approx_derivative,group_columns
from scipy.sparse import diags
from scipy.sparse.linalg import splu
from radiating_star_2d import Model

def newton(m,y,maxiter=30):
    pattern=m.sparsity(); groups=group_columns(pattern)
    print('COLORS',np.max(groups)+1,flush=True)
    damping=1e-3
    for k in range(maxiter):
        begin=time.monotonic(); f=m.residual(y); norm=np.linalg.norm(f); peak=max(abs(f))
        print('NEWTON',k,'norm',norm,'max',peak,'damping',damping,flush=True)
        if peak<1e-8:return y,True
        jac=approx_derivative(m.residual,y,method='3-point',f0=f,sparsity=(pattern,groups))
        colnorm=np.sqrt(np.asarray(jac.power(2).sum(axis=0)).ravel())
        scale=np.minimum(1/np.maximum(colnorm,1e-14),10.)
        js=(jac@diags(scale)).tocsc()
        normal=(js.T@js).tocsc(); rhs=-js.T@f
        accepted=False
        for attempt in range(15):
            try:
                delta=scale*splu(normal+damping*diags(np.ones(len(y)))).solve(rhs)
            except Exception as exc:
                print('FACTOR FAILED',damping,type(exc).__name__,flush=True);damping*=10;continue
            candidate=y+delta
            shaped=candidate.reshape(5,m.n,m.n)
            valid=np.all(np.isfinite(candidate)) and np.max(np.abs(shaped[1]))<20 and np.max(np.abs(shaped[2:4]))<100
            if valid:
                with np.errstate(over='ignore',invalid='ignore',divide='ignore'):
                    trial=m.residual(candidate)
                nextnorm=np.linalg.norm(trial)
                predicted=norm*norm-np.linalg.norm(f+jac@delta)**2
                ratio=(norm*norm-nextnorm*nextnorm)/predicted if predicted>0 else -1
                if np.isfinite(nextnorm) and ratio>.05:
                    accepted=True;y=candidate
                    print('ACCEPT','ratio',ratio,'newnorm',nextnorm,'delta',max(abs(delta)),'sec',time.monotonic()-begin,flush=True)
                    if ratio>.75:damping=max(1e-14,damping/3)
                    elif ratio<.25:damping*=3
                    break
            damping*=10
        if not accepted:
            print('NO DESCENT',flush=True);return y,False
    return y,False

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--n',type=int,default=13);p.add_argument('--iterations',type=int,default=35);p.add_argument('--outer',type=int,default=3);p.add_argument('--spins',type=float,nargs='+',default=[0,.1]);a=p.parse_args()
    m=Model(a.n,0);y=m.initial.ravel()
    for spin in a.spins:
      m.omega2=spin**2*m.info['M']/m.info['R']**3
      for outer in range(a.outer):
        m.update_boundary(y)
        rho=m.decode(y)[2];newmask=rho>m.info['cut'];changed=np.sum(newmask!=m.mask);m.mask=newmask
        print('START','spin',spin,'outer',outer,'maskchanges',changed,flush=True)
        y,success=newton(m,y,a.iterations)
        r=m.residual(y).reshape(5,a.n,a.n)
        print('RESULT','spin',spin,'outer',outer,'ok',success,'norm',np.linalg.norm(r),'blocks',[max(abs(x).ravel()) for x in r],flush=True)
        np.savez('/tmp/radiating_star_newton_audit.npz',solution=y.reshape(5,a.n,a.n),x=m.x,residual=r,spin=spin)
        if not success:break
      if not success:break
