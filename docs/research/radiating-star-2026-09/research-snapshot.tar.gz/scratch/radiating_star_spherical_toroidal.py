"""Toroidal radiation correction for the r,mu reference grid.

Uses q_phi=F_phi/c=sqrt(1-mu^2) W and v_phi=sqrt(1-mu^2) V.
The outgoing azimuthal M1 stress remains part of the solution.
"""
import argparse
import numpy as np
from scipy.sparse import diags
from scipy.sparse.linalg import spsolve
from radiating_star_spherical_grid import SphericalModel


def rotation(m,y):
    h,p,rho,T,E,F,Q=m.decode(y)
    h0,p0,_,_,E0,F0,Q0=m.decode(m.initial.ravel())
    dS=(h+p-h0-p0).ravel()
    deltaF=(F-F0).ravel();deltaQ=Q.ravel()
    rr=m.re@dS; mm=m.me@dS
    ir=m.ir.diagonal();mu=m.MU.ravel()
    w2=ir*(rr-mu*ir*mm-m.kappa.ravel()*(deltaF-mu*deltaQ))
    w2=w2.reshape(m.nr,m.nm)
    w2[0]=w2[1]
    return w2


def toroidal(m,y,omega2,c=520.3906):
    h,p,rho,T,E,F,Q=[a.ravel() for a in m.decode(y)]
    mu=m.MU.ravel();ss=m.S.ravel();ir=m.ir.diagonal()
    fr=F/E;q=Q/E;f2=fr*fr+ss*q*q;b=3/(2+np.sqrt(4-3*f2))
    ar=b*fr;aq=b*q;pp=E*(1/3-b*f2/3);B=.75*T**4
    chi=m.kappa.ravel()*rho
    matrix=(m.re@diags(ar)+m.ir@(diags(3*ar)+m.sm@m.mo@diags(aq)-diags(4*mu*aq))+diags(chi)).tolil()
    V=m.r.ravel()*np.sqrt(np.maximum(0,omega2.ravel()))
    rhs=chi*(pp+B)*V/c
    matrix[m.center]=0;matrix[m.center,m.center]=1;rhs[m.center]=0
    W=spsolve(matrix.tocsr(),rhs)
    phi=np.sqrt(ss)*W;beta=np.sqrt(ss)*V/c
    totalf2=f2+phi*phi/(E*E);bfull=3/(2+np.sqrt(4-3*totalf2))
    Pphi=E*(1/3-bfull*totalf2/3)+bfull*phi*phi/E
    thermal=E-B-2*beta*phi+beta*beta*(Pphi+B)
    sourceWork=chi*beta*(phi-(Pphi+B)*beta)
    return {name:v.reshape(m.nr,m.nm) for name,v in dict(W=W,thermal=thermal,sourceWork=sourceWork,
      fphi=phi/E,beta=beta,forceFraction=beta*bfull*phi/E).items()}


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('path');args=parser.parse_args()
    data=np.load(args.path);y=data['solution'];nr,nm=y.shape[1:];m=SphericalModel(nr,nm,0)
    omega2=rotation(m,y);out=toroidal(m,y,omega2)
    h,p,rho,T,E,F,Q=m.decode(y)
    for cut in [.01,.001,1e-5]:
        active=(rho>cut)&(m.r>0)
        print('omega²',cut,omega2[active].min(),omega2[active].max(),'negative',sum(omega2[active]<0),flush=True)
    active=m.mask&(m.r>0)
    for name in ['beta','fphi','forceFraction']:
        print(name,np.max(np.abs(out[name][active])),flush=True)
    print('thermal/E',np.max(np.abs(out['thermal'][active]/E[active])),flush=True)
    np.savez('/tmp/radiating_star_toroidal_result.npz',**out,omega2=omega2)
