"""Linear-in-v/c azimuthal M1 momentum balance on a meridional grid.

This is a reference-generation prototype, never an evolution force correction.
q=F_phi/c, and a_i=(3D-1) f_i/(2 |f|^2), so P_i,phi=a_i q.
The stationary equation is d_R(a_R q)+d_z(a_z q)+2 a_R q/R
    + chi q = chi (P_phi,phi + B) v_phi/c.
"""
import numpy as np
from scipy.sparse import lil_matrix, kron, eye, diags
from scipy.sparse.linalg import spsolve


def solve_toroidal(x, rho, E, fr, fz, blackbody, opacity, velocity_over_c):
    n=len(x); dx=x[1]-x[0]; N=n*n
    even=lil_matrix((n,n)); odd=lil_matrix((n,n))
    for i in range(1,n-1):
        even[i,i-1]=-0.5/dx; even[i,i+1]=0.5/dx
    even[-1,-3]=.5/dx; even[-1,-2]=-2/dx; even[-1,-1]=1.5/dx
    odd[:]=even; odd[0,1]=1/dx
    dr=kron(even.tocsr(),eye(n),format='csr')
    dz=kron(eye(n),odd.tocsr(),format='csr')
    R=np.broadcast_to(x[:,None],(n,n))
    f2=fr*fr+fz*fz; b=3/(2+np.sqrt(4-3*f2))
    ar=b*fr; az=b*fz; pressure=E*(1/3-b*f2/3)
    geometric=np.divide(2*ar,R,out=np.zeros_like(R),where=R>0)
    chi=opacity*rho
    matrix=(dr@diags(ar.ravel())+dz@diags(az.ravel())+diags((geometric+chi).ravel())).tolil()
    rhs=(chi*(pressure+blackbody)*velocity_over_c).ravel()
    # Regularity q=O(R) at the axis; no incoming characteristics outside.
    matrix[:n]=0
    for j in range(n):matrix[j,j]=1
    rhs[:n]=0
    q=spsolve(matrix.tocsr(),rhs).reshape(n,n)
    return q, np.linalg.norm(matrix@q.ravel()-rhs), pressure


if __name__=='__main__':
    from radiating_star_2d import spherical
    from scipy.integrate import solve_ivp
    from scipy.interpolate import PchipInterpolator
    info,ref=spherical()
    cap=1.7*info['R']; omega=.2*np.sqrt(info['M']/info['R']**3); c=520.
    # Independent one-dimensional radial equation q=R w(r).
    r=np.linspace(1e-5,2*cap,16001)
    rho=ref['rho'](r); f=ref['f'](r); E=ref['E'](r)
    b=3/(2+np.sqrt(4-3*f*f)); a=b*f
    ai=PchipInterpolator(r,a); ei=PchipInterpolator(r,E)
    kap=info['kappa']*np.maximum(0,1-info['cut']/np.maximum(rho,1e-30))**2
    ci=PchipInterpolator(r,kap*rho); pi=PchipInterpolator(r,E*(1/3-b*f*f/3))
    def rhs(rad,y):
        chi=max(0,ci(rad)); aa=ai(rad)
        return (chi*(pi(rad)+ei(rad))*omega/c-(ai(rad,1)+4*aa/rad+chi)*y)/aa
    w0=ci(r[0])*(pi(r[0])+ei(r[0]))*omega/c/(5*a[0]/r[0]+ci(r[0]))
    sol=solve_ivp(rhs,[r[0],r[-1]],[w0],method='Radau',rtol=1e-9,atol=1e-15,dense_output=True,max_step=.02)
    for n in [17,33,65,129]:
        x=np.linspace(0,cap,n); R,Z=np.meshgrid(x,x,indexing='ij');rad=np.hypot(R,Z)
        rho=ref['rho'](rad);E=ref['E'](rad);f=ref['f'](rad)
        fr=np.divide(f*R,rad,out=np.zeros_like(R),where=rad>0)
        fz=np.divide(f*Z,rad,out=np.zeros_like(R),where=rad>0)
        kap=info['kappa']*np.maximum(0,1-info['cut']/np.maximum(rho,1e-30))**2
        q,res,pp=solve_toroidal(x,rho,E,fr,fz,E,kap,omega*R/c)
        expected=R*sol.sol(np.maximum(rad,r[0]).ravel())[0].reshape(n,n)
        measure=np.sqrt(np.sum(R*(q-expected)**2)/np.sum(R*expected**2))
        torque=(kap*rho*(q-(pp+E)*omega*R/c))*R
        print(n,'relativeL2',measure,'residual',res,'minq',q.min(),'torque',np.trapz(np.trapz(torque*R,x,axis=1),x),flush=True)
