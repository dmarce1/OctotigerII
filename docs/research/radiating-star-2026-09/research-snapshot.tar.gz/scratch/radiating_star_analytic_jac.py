"""Exact sparse Jacobian of current Cartesian prototype with direct flux factors."""
import numpy as np
from scipy.sparse import lil_matrix,diags,kron,eye,bmat,csr_matrix

def _ops(m):
    if hasattr(m,'_analytic_ops'):return m._analytic_ops
    n=m.n;N=n*n;dx=m.dx
    def derivative(odd):
        a=lil_matrix((n,n));
        for i in range(1,n-1):a[i,i-1]=-1/(2*dx);a[i,i+1]=1/(2*dx)
        a[-1,-3]=1/(2*dx);a[-1,-2]=-2/dx;a[-1,-1]=3/(2*dx)
        if odd:a[0,1]=1/dx
        return a.tocsr()
    re=kron(derivative(False),eye(n),format='csr');ro=kron(derivative(True),eye(n),format='csr')
    ze=kron(eye(n),derivative(False),format='csr');zo=kron(eye(n),derivative(True),format='csr')
    inverse=np.divide(1,m.R.ravel(),out=np.zeros(N),where=m.R.ravel()>0);ri=diags(inverse)
    rp=(ro+ri).tolil();rp[:n]=2*ro[:n];rp=rp.tocsr()
    gas=ze.tolil();equator=np.arange(0,N,n);gas[equator]=re[equator];gas=gas.tocsr()
    lap=lil_matrix((N,N));boundary=[]
    for i in range(n):
      for j in range(n):
        k=i*n+j
        if i==n-1 or j==n-1:boundary.append(k);continue
        if i==0:
            lap[k,k]-=4/dx**2;lap[k,k+n]+=4/dx**2
        else:
            lap[k,k]-=2/dx**2;lap[k,k+n]+=1/dx**2+1/(2*dx*m.R[i,j]);lap[k,k-n]+=1/dx**2-1/(2*dx*m.R[i,j])
        if j==0:
            lap[k,k]-=2/dx**2;lap[k,k+1]+=2/dx**2
        else:
            lap[k,k]-=2/dx**2;lap[k,k+1]+=1/dx**2;lap[k,k-1]+=1/dx**2
    m._analytic_ops=(re,ro,ze,zo,ri,rp,gas,lap.tocsr(),np.array(boundary),equator)
    return m._analytic_ops

def jacobian(m,y):
    n=m.n;N=n*n;re,ro,ze,zo,ri,rp,gas,lap,boundary,equator=_ops(m)
    h,phi,rho,T,E,FR,FZ,kap=[x.ravel() for x in m.decode(y)]
    hp=np.maximum(0,h)
    drho=np.where(h>0,m.ref['density'].derivative()(hp),0)*m.hscale
    dtemp=np.where(h>0,m.ref['temperature'].derivative()(hp),0)*m.hscale
    drho=np.where(rho>0,drho,0);dtemp=np.where(T>0,dtemp,0)
    kR=np.zeros(N);kZ=np.ones(N);kR[equator]=1;kZ[equator]=0;kR[0]=0
    kZ[0]=0;fs=m.forceScale.ravel();rs=m.radScale.ravel();inside=m.mask.ravel().astype(float);outside=1-inside
    z=csr_matrix((N,N));rows=[]
    gh=(diags(1/fs)@gas*m.hscale).tolil();gp=gh.copy();gh[0]=0;gh[0,0]=1;gp[0]=0
    rows.append([gh.tocsr(),diags(-kap*(kR*FR+kZ*FZ)/fs),diags(-kap*kR*E/fs),diags(-kap*kZ*E/fs),gp.tocsr()])
    blackbody=.75*T**4;den=np.maximum(E,1e-8)
    te=inside*np.where(E>=1e-8,blackbody/E,E/1e-8)
    th=-inside*3*T**3*dtemp/den
    W=diags(outside/rs)
    rows.append([diags(th),diags(te)+W@(rp@diags(FR)+zo@diags(FZ)),W@rp@diags(E),W@zo@diags(E),z])
    fr=FR/E;fz=FZ/E;q=fr*fr+fz*fz;s=np.sqrt(4-3*q);b=3/(2+s);db=b*b/(2*s)
    A=E*(1/3-b*q/3);AR=E*(-2*fr*(db*q+b)/3);AZ=E*(-2*fz*(db*q+b)/3)
    RR=E*(1/3+b*(fr*fr-q/3));RRR=E*2*fr*(db*(fr*fr-q/3)+2*b/3);RRZ=E*2*fz*(db*(fr*fr-q/3)-b/3)
    ZZ=E*(1/3+b*(fz*fz-q/3));ZZR=E*2*fr*(db*(fz*fz-q/3)-b/3);ZZZ=E*2*fz*(db*(fz*fz-q/3)+2*b/3)
    RZ=E*b*fr*fz;RZR=E*fz*(2*fr*fr*db+b);RZZ=E*fr*(2*fz*fz*db+b)
    chi=kap*rho;W=diags(1/rs)
    radial=[diags(kap*drho*FR/rs),W@((re+ri)@diags(RR)+zo@diags(RZ)-ri@diags(A)+diags(chi*FR)),W@((re+ri)@diags(RRR)+zo@diags(RZR)-ri@diags(AR)+diags(chi*E)),W@((re+ri)@diags(RRZ)+zo@diags(RZZ)-ri@diags(AZ)),z]
    vertical=[diags(kap*drho*FZ/rs),W@(rp@diags(RZ)+ze@diags(ZZ)+diags(chi*FZ)),W@(rp@diags(RZR)+ze@diags(ZZR)),W@(rp@diags(RZZ)+ze@diags(ZZZ)+diags(chi*E)),z]
    for field,row in [(2,radial),(3,vertical)]:
        chosen=np.arange(n) if field==2 else equator
        for c in range(5):
            a=row[c].tolil();a[chosen]=0
            if c==field:a[chosen,chosen]=1
            row[c]=a.tocsr()
        rows.append(row)
    gravh=diags(-drho).tolil();gravh[boundary]=0
    gravp=(m.hscale*lap).tolil();gravp[boundary,boundary]=1
    rows.append([gravh.tocsr(),z,z,z,gravp.tocsr()])
    return bmat(rows,format='csr')
