"""Analytic-background M1 continuation with integrated meridional gas balance."""
import argparse
import numpy as np
from scipy.integrate import cumulative_trapezoid
from scipy.sparse import csr_matrix,diags,eye,bmat,lil_matrix
import radiating_star_defect_direct as direct
from radiating_star_defect_direct import DefectModel,FluxModel
from radiating_star_analytic_jac import jacobian as local_jacobian

class IntegralModel(DefectModel):
 def __init__(self,*args,**kwargs):
  super().__init__(*args,**kwargs)
  n=self.n;N=n*n;ir=lil_matrix((N,N));iz=lil_matrix((N,N))
  for i in range(n):
   for j in range(n):
    row=i*n+j
    if i:
     ir[row,0]=self.dx/2;ir[row,i*n]=self.dx/2
     for k in range(1,i):ir[row,k*n]=self.dx
    if j:
     iz[row,i*n]=self.dx/2;iz[row,i*n+j]=self.dx/2
     for k in range(1,j):iz[row,i*n+k]=self.dx
  self.ir=ir.tocsr();self.iz=iz.tocsr()
  self.baseline=self.rawresidual(self.initial.ravel())
 def rawresidual(self,y):
  result=FluxModel.residual(self,y).reshape(5,self.n,self.n)
  h,phi,rho,T,E,FR,FZ,kap=self.decode(y)
  ir=cumulative_trapezoid(kap[:,0]*FR[:,0],self.x,initial=0)[:,None]
  iz=cumulative_trapezoid(kap*FZ,self.x,axis=1,initial=0)
  result[0]=(h+phi-self.hscale-phi[0,0]-.5*self.omega2*self.R*self.R-ir-iz)/self.hscale
  result[0,0,0]=h[0,0]/self.hscale-1
  return result.ravel()
 def residual(self,y):return self.rawresidual(y)-self.baseline

def jacobian(m,y):
 n=m.n;N=n*n
 j=local_jacobian(m,y).tolil()
 h,phi,rho,T,E,FR,FZ,kap=[a.ravel() for a in m.decode(y)]
 gp=eye(N,format='lil');gp[:,0]=-1;gp[0]=0
 for k in range(1,N):gp[k,k]=1
 gh=eye(N,format='csr')
 ge=-(m.ir@diags(kap*FR)+m.iz@diags(kap*FZ))/m.hscale
 gr=-m.ir@diags(kap*E)/m.hscale;gz=-m.iz@diags(kap*E)/m.hscale
 j[:N]=bmat([[gh,ge,gr,gz,gp]],format='csr')
 return j.tocsr()

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--resume');p.add_argument('--n',type=int,default=25);p.add_argument('--iterations',type=int,default=40);p.add_argument('--outer',type=int,default=5);p.add_argument('--spins',type=float,nargs='+',default=[.03,.1,.2]);a=p.parse_args()
 direct.jacobian=jacobian
 m=IntegralModel(a.n,0);y=m.initial.ravel()
 if a.resume:y=np.load(a.resume)['solution'].ravel().copy()
 for spin in a.spins:
  m.omega2=spin**2*m.info['M']/m.info['R']**3
  for outer in range(a.outer):
   m.update_boundary(y)
   print('START','spin',spin,'outer',outer,flush=True)
   y,success=direct.newton(m,y,a.iterations)
   r=m.residual(y).reshape(5,a.n,a.n)
   print('RESULT','spin',spin,'outer',outer,'ok',success,'norm',np.linalg.norm(r),'blocks',[max(abs(x).ravel()) for x in r],flush=True)
   np.savez(f'/tmp/radiating_star_integral_{a.n}_{spin}.npz',solution=y.reshape(5,a.n,a.n),x=m.x,residual=r,spin=spin,phib=m.phib)
   if not success:break
  if not success:break
