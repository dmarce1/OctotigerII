"""Independent sparse direct Newton audit of the root's stationary prototype."""
import argparse,time,warnings
import numpy as np
from scipy.optimize._numdiff import approx_derivative,group_columns
from scipy.sparse import diags
from scipy.sparse.linalg import splu
from radiating_star_2d import Model

class FluxModel(Model):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        w=self.initial[2:4].copy();self.initial[2:4]=w/np.sqrt(1+np.sum(w*w,axis=0))
    def decode(self,y):
        h,logE,fR,fZ,phi=y.reshape(5,self.n,self.n)
        h=h*self.hscale;phi=phi*self.hscale
        rho=np.maximum(self.ref['density'](np.maximum(0,h)),0)
        T=np.maximum(self.ref['temperature'](np.maximum(0,h)),0)
        E=self.Eref*np.exp(logE)
        kap=self.kappa
        return h,phi,rho,T,E,E*fR,E*fZ,kap

def cone_step(m,y,delta):
    f=y.reshape(5,m.n,m.n)[2:4];df=delta.reshape(5,m.n,m.n)[2:4]
    aa=np.sum(df*df,axis=0);bb=2*np.sum(f*df,axis=0);cc=np.sum(f*f,axis=0)-(1-1e-9)**2
    disc=np.sqrt(np.maximum(0,bb*bb-4*aa*cc))
    roots=np.full_like(aa,np.inf)
    active=aa>0
    pos=active&(bb>=0);neg=active&(bb<0)
    roots[pos]=-2*cc[pos]/(bb[pos]+disc[pos])
    roots[neg]=(-bb[neg]+disc[neg])/(2*aa[neg])
    alpha=min(1.,.99*np.min(roots))
    logs=delta.reshape(5,m.n,m.n)[1]
    alpha=min(alpha,2/max(2,np.max(np.abs(logs))))
    return alpha

def newton(m,y,maxiter=30):
    pattern=m.sparsity(); groups=group_columns(pattern)
    print('COLORS',np.max(groups)+1,flush=True)
    for k in range(maxiter):
        begin=time.monotonic(); f=m.residual(y); norm=np.linalg.norm(f); peak=max(abs(f))
        print('NEWTON',k,'norm',norm,'max',peak,flush=True)
        if peak<1e-8:return y,True
        jac=approx_derivative(m.residual,y,method='3-point',f0=f,sparsity=(pattern,groups))
        colnorm=np.sqrt(np.asarray(jac.power(2).sum(axis=0)).ravel())
        scale=np.minimum(1/np.maximum(colnorm,1e-14),10.)
        js=(jac@diags(scale)).tocsc()
        accepted=False; bestnorm=norm; besty=None; bestinfo=None
        for regularization in [0.,1e-7,1e-5,.001,.01,.1,1.]:
            try:
                if regularization==0:
                    delta=scale*splu(js).solve(-f)
                else:
                    normal=(js.T@js+regularization*diags(np.ones(len(y)))).tocsc()
                    delta=scale*splu(normal).solve(-js.T@f)
            except Exception as exc:
                print('FACTOR FAILED',regularization,type(exc).__name__,flush=True);continue
            if not np.all(np.isfinite(delta)):continue
            step=cone_step(m,y,delta)
            if step<1e-4:continue
            for line in range(10):
                candidate=y+step*delta
                logs=candidate.reshape(5,m.n,m.n)[1]
                if np.max(np.abs(logs))<20:
                    with np.errstate(over='ignore',invalid='ignore',divide='ignore'):
                        trial=m.residual(candidate)
                    nextnorm=np.linalg.norm(trial)
                    if np.isfinite(nextnorm) and nextnorm<(1-1e-4*step)*norm:
                        if nextnorm<bestnorm:
                            accepted=True;bestnorm=nextnorm;besty=candidate;bestinfo=(step,regularization,max(abs(step*delta)))
                        break
                step*=.5
        if accepted:
            y=besty
            print('ACCEPT','alpha',bestinfo[0],'reg',bestinfo[1],'newnorm',bestnorm,'delta',bestinfo[2],'sec',time.monotonic()-begin,flush=True)
        if not accepted:
            print('NO DESCENT',flush=True);return y,False
    return y,False

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--n',type=int,default=13);p.add_argument('--iterations',type=int,default=35);p.add_argument('--outer',type=int,default=3);p.add_argument('--spins',type=float,nargs='+',default=[0,.1]);a=p.parse_args()
    m=FluxModel(a.n,0);y=m.initial.ravel()
    for spin in a.spins:
      m.omega2=spin**2*m.info['M']/m.info['R']**3
      for outer in range(a.outer):
        m.update_boundary(y)
        changed=0
        print('START','spin',spin,'outer',outer,'maskchanges',changed,flush=True)
        y,success=newton(m,y,a.iterations)
        r=m.residual(y).reshape(5,a.n,a.n)
        print('RESULT','spin',spin,'outer',outer,'ok',success,'norm',np.linalg.norm(r),'blocks',[max(abs(x).ravel()) for x in r],flush=True)
        np.savez(f'/tmp/radiating_star_flux_newton_{a.n}_{spin}.npz',solution=y.reshape(5,a.n,a.n),x=m.x,residual=r,spin=spin)
        if not success:break
      if not success:break
