import sys, argparse, importlib
import numpy as np
sys.path.insert(0,'/home/dmarce1/workspace/OctotigerII/tools/science')
from radiating_star_rotation import angular_velocity_squared, toroidal_flux, light_speed, moving_residual

p=argparse.ArgumentParser();p.add_argument('path');p.add_argument('--module',default='radiating_star_spherical_graded_lte');p.add_argument('--output',default='/tmp/radiating_star_moving.npz');a=p.parse_args()
module=importlib.import_module(a.module)
data=np.load(a.path); y=data['solution'].ravel().copy(); nr,nm=data['solution'].shape[1:]
m=module.SphericalModel(nr,nm,0,4)
assert np.max(np.abs(m.x-data['x']))<1e-10
spin=float(data['spin']);m.omega2=spin**2*m.info['M']/m.info['R']**3;m.phib=data['phib'].copy()
c=light_speed();W=None
for iteration in range(4):
    omega2=angular_velocity_squared(m,y,W,c)
    W=toroidal_flux(m,y,omega2,c,W)
    beta=m.R*np.sqrt(omega2)/c
    m.residual=lambda trial:moving_residual(m,trial,W,beta)
    residual=m.residual(y)
    print('PICARD',iteration,'residual',max(abs(residual)),'v/c',beta.max(),'Wmax',W.max(),flush=True)
    y,okay=module.solve(m,y,8)
    if not okay:raise RuntimeError('Mixed reference solve failed')
    m.update_boundary(y)
np.savez(a.output,solution=y.reshape(5,nr,nm),W=W,beta=beta,omega2=omega2,x=m.x,mu=m.mu,phib=m.phib,
         residual=m.residual(y).reshape(5,nr,nm),spin=spin,cDimensionless=c)
print('FINAL',max(abs(m.residual(y))),a.output,flush=True)
