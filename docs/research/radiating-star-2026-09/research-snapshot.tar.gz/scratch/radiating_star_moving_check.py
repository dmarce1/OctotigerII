import argparse
import numpy as np
from radiating_star_defect_direct import DefectModel
from radiating_star_toroidal import solve_toroidal

p=argparse.ArgumentParser();p.add_argument('path');a=p.parse_args()
data=np.load(a.path);y=data['solution'];n=y.shape[1];m=DefectModel(n,0)
h,phi,rho,T,E,FR,FZ,kap=m.decode(y)
h0,p0,rho0,T0,E0,FR0,FZ0,_=m.decode(m.initial)
drh,_=m.grad(h-h0);drp,_=m.grad(phi-p0)
omega2=np.divide(drh+drp-kap*(FR-FR0),m.R,out=np.zeros_like(m.R),where=m.R>0)
omega2[0]=omega2[1]
for limit in [.01,.001,1e-5]:
    active=rho>limit
    print('omega2',limit,np.min(omega2[active]),np.max(omega2[active]),'negative',np.count_nonzero(omega2[active]<0),flush=True)
frr,_=m.grad(FR-FR0,oddR=True);_,fzz=m.grad(FZ-FZ0,oddZ=True)
dj=frr+fzz+np.divide(FR-FR0,m.R,out=np.zeros_like(m.R),where=m.R>0);dj[0]=2*frr[0]+fzz[0]
rf=m.ref['f'];re=m.ref['E'];r=m.r
j0=rf.derivative()(r)*re(r)+rf(r)*re.derivative()(r)+np.divide(2*rf(r)*re(r),r,out=np.zeros_like(r),where=r>0)
j0[0,0]=3*rf.derivative()(0)*re(0);j=j0+dj
print('heatingcore',j[m.mask].min(),j[m.mask].max(),'jref',j0[m.mask].min(),'negative',np.count_nonzero(j[m.mask]<0),flush=True)
v=np.sqrt(np.maximum(0,omega2))*m.R; vc=v/520.
q,res,pp=solve_toroidal(m.x,rho,E,FR/E,FZ/E,.75*T**4,kap,vc)
f2=(FR*FR+FZ*FZ+q*q)/(E*E);b=3/(2+np.sqrt(4-3*f2));Pphi=E*(1/3-b*f2/3)+b*q*q/E
B=.75*T**4
thermal=E-B-2*vc*q+vc*vc*(Pphi+B)
Q=kap*rho*(E-B-vc*q)
Gphi=kap*rho*(q-(Pphi+B)*vc)
scale=np.maximum(j,1e-30)
active=m.mask&(rho>.01)
print('v/c',vc[rho>1e-5].max(),'q/E',np.max(np.abs(q/E)),'maxf',np.sqrt(f2).max(),'thermal/E',np.max(np.abs(thermal[active]/E[active])),
      'thermal/heating',np.max(np.abs((kap*rho*thermal/scale)[active])), 'torusResidual',res,flush=True)
print('rotwork',np.max(np.abs((vc*Gphi/scale)[active])), 'thermalDeltaE',np.max(np.abs(2*vc*q-vc*vc*(Pphi+B))),flush=True)
